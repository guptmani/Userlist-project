﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Web.Mvc;
using MvcDemo.Models;
using BusinessLayer;

namespace MvcDemo.Controllers
{
    public class UserListController : Controller
    {
      
        public ActionResult Index()
        {
            UserListBusinessLayer userListBusinessLayer = new UserListBusinessLayer();
            List<UserList> userList = userListBusinessLayer.Userlist.ToList();

            return View(userList);
        }

        [HTTPGet]
        public ActionResult Edit(int id)
        {
            UserListBusinessLayer userListBusinessLayer = new UserListBusinessLayer();
            UserList userList = userListBusinessLayer.Userlist.Single(user => user.userID == id);

            return View(userList);
        }


        [HTTPPost]
        public ActionResult Edit(UserList userList)
        {

            if (ModelState.isValid)
            {
                UserListBusinessLayer userListBusinessLayer = new UserListBusinessLayer();
                UserList userList = userListBusinessLayer.SaveUser(userList);

                return RedirectToAction("Index");
            }
            return View(userList);
        }
    }
}
